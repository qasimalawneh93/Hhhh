#!/bin/bash
set -e

# --- Backend Setup ---
# Scaffold Laravel if not already present
if [ ! -f backend/artisan ]; then
  echo "Scaffolding Laravel project..."
  composer create-project laravel/laravel backend_temp --prefer-dist --no-interaction
  # Copy API files
  rm -rf backend_temp/app
  mkdir -p backend_temp/app
  cp -r backend/app/* backend_temp/app
  rm -f backend_temp/config/cors.php
  cp backend/config/cors.php backend_temp/config/cors.php
  rm -rf backend_temp/database/migrations
  mkdir -p backend_temp/database/migrations
  cp backend/database/migrations/* backend_temp/database/migrations
  rm -f backend_temp/routes/api.php
  cp backend/routes/api.php backend_temp/routes/api.php
  # Replace backend dir
  rm -rf backend
  mv backend_temp backend
fi

# Install Composer deps, generate key, migrate
cd backend
composer install --optimize-autoloader
php artisan key:generate --ansi
php artisan migrate --force &

# --- Frontend Setup ---
cd ../frontend
npm install
npm run dev -- --host 0.0.0.0 --port 3000
