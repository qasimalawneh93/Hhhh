# Zenith Backend

## Setup Instructions

1. Copy `.env.example` to `.env` and fill in your DB credentials.
2. Run `composer install`.
3. Generate app key: `php artisan key:generate`.
4. Run migrations: `php artisan migrate`.
5. Serve the app: `php artisan serve --port=8000`.

The API endpoints are now available at `http://localhost:8000/api/lessons`.
