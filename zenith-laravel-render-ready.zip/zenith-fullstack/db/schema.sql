-- MySQL database schema for Zenith project
CREATE DATABASE IF NOT EXISTS zenith_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE zenith_db;

-- Lessons table
CREATE TABLE IF NOT EXISTS lessons (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP NULL,
    updated_at TIMESTAMP NULL
);
